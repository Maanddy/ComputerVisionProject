"""Configuration file to manage all parameters"""
import os

# Video source configuration
VIDEO_SOURCE = "1.mp4"  # Default: use video file; can be a file path, camera index, or streaming URL

# Detection and tracking configuration
MODEL_PATH = "yolo11s.pt"  # Path to YOLOv8 model (default: yolov8n)
DEVICE = "gpu"  # Device to run model on; use "cpu" or GPU device index
CONF_THRESH = 0.2  # Detection confidence threshold
IOU_THRESH = 0.45  # Non-Maximum Suppression (NMS) IoU threshold
CLASSES = [0]  # Detect only person class (class ID 0 in COCO dataset)
TRACK_HISTORY_LEN = 80  # Length of tracking history (number of points to store)

# Display settings
SHOW_FPS = True  # Whether to display FPS
SHOW_TRACK = True  # Whether to display tracking trajectories
LINE_THICKNESS = 5  # Thickness of tracking lines
FONT_SIZE = 0.6  # Font scale for text display
FONT_THICKNESS = 2  # Thickness of the font used in drawing
TRACK_FADE_FACTOR = 10  # Factor controlling how fast the trajectory line fades (smaller = faster fade)

# Color settings (in BGR format)
TEXT_COLOR = (255, 255, 255)  # Text color: white

# Output settings
SAVE_OUTPUT = True  # Whether to save output video
# Use source file name as prefix for output
SOURCE_NAME = os.path.splitext(os.path.basename(VIDEO_SOURCE))[0] if isinstance(VIDEO_SOURCE, str) and not VIDEO_SOURCE.isdigit() else "camera"
OUTPUT_PATH = f"{SOURCE_NAME}_output.mp4"  # Output video file path
OUTPUT_FPS = 30  # Output video frame rate
VIDEO_CODEC = "mp4v"  # Video codec format
