import sys
import cv2
import numpy as np
from PySide6.QtWidgets import QApplication, QWidget, QFileDialog, QMessageBox
from PySide6.QtCore import Qt, QTimer, QCoreApplication
from PySide6.QtGui import QPixmap, QImage
from ultralytics import YOLO
import utils
import config
from collections import defaultdict

from main_ui import Ui_Form  # 请确保已经使用 pyside6-uic 转换了 .ui 文件


def cvimg_to_qpiximg(cv_img):
    height, width, channel = cv_img.shape
    bytes_per_line = 3 * width
    q_img = QImage(cv_img.data, width, height, bytes_per_line, QImage.Format_BGR888)
    return QPixmap.fromImage(q_img)


def get_y_on_line(x, p1, p2):
    x1, y1 = p1
    x2, y2 = p2
    if x2 - x1 == 0:
        return (y1 + y2) / 2
    k = (y2 - y1) / (x2 - x1)
    b = y1 - k * x1
    return k * x + b


class MyWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Form()
        self.ui.setupUi(self)

        self.bind()

        self.cap = None

        self.cross_count = 0
        self.prev_centers = []
        self.frame_id = 0
        self.process_every_n_frames = 1
        self.drag_line = {"p1": [0, 370], "p2": [640, 320]}

    def bind(self):
        self.ui.video.clicked.connect(lambda: self.open_video("file"))
        self.ui.camera.clicked.connect(lambda: self.open_video("camera"))
        self.ui.exit.clicked.connect(self.exit)

    def open_video(self, source_type):
        self.model = YOLO("yolov8n.pt")
        if self.cap:
            self.cap.release()
        self.cross_count = 0
        self.prev_centers.clear()
        self.frame_id = 0
        if source_type == "file":
            file_path, _ = QFileDialog.getOpenFileName(self, "select video files", "", "Video Files (*.mp4 *.avi)")
            if not file_path:
                return
            self.cap = cv2.VideoCapture(file_path)
        elif source_type == "camera":
            self.cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
            if not self.cap.isOpened():
                QMessageBox.warning(self, "Error", "Camera is not opened")
                return
        # Store the track history

        track_history = defaultdict(lambda: [])

        # Loop through the video frames
        while self.cap.isOpened():
            # Read a frame from the video
            success, frame = self.cap.read()

            if not success:
                break

            img = cvimg_to_qpiximg(frame)
            scaled_pixmap = img.scaled(
                self.ui.output.width(),
                self.ui.output.height(),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
            self.ui.input.setPixmap(
                scaled_pixmap.scaled(self.ui.input.width(), self.ui.input.height(), Qt.KeepAspectRatio))

            if success:
                # Run YOLO11 tracking on the frame, persisting tracks between frames
                result = self.model.track(frame, persist=True,classes=[0])[0]

                # Get the boxes and track IDs
                if result.boxes and result.boxes.id is not None:
                    boxes = result.boxes.xywh.cpu()
                    track_ids = result.boxes.id.int().cpu().tolist()

                    # Visualize the result on the frame
                    frame = result.plot()

                    # Plot the tracks
                    for box, track_id in zip(boxes, track_ids):
                        x, y, w, h = box
                        track = track_history[track_id]
                        track.append((float(x), float(y)))  # x, y center point
                        if len(track) > 30:  # retain 30 tracks for 30 frames
                            track.pop(0)

                        # Draw the tracking lines
                        points = np.hstack(track).astype(np.int32).reshape((-1, 1, 2))
                        cv2.polylines(frame, [points], isClosed=False, color=(230, 230, 230), thickness=10)

                pixmap = cvimg_to_qpiximg(frame)
                self.ui.output.setPixmap(pixmap.scaled(self.ui.output.width(), self.ui.output.height(), Qt.KeepAspectRatio))
                QApplication.processEvents()
            else:
                # Break the loop if the end of the video is reached
                break
        self.cap.release()



    def exit(self):
        if self.cap:
            self.cap.release()
        QCoreApplication.quit()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MyWindow()
    window.show()
    sys.exit(app.exec_())
