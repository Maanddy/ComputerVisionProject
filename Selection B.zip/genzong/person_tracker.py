"""Main Program: Video-based Person Tracking System"""
import cv2
import time
from ultralytics import YOLO
import config
import utils


def main():
    """Main function: Initialize and run the person tracking system"""
    # Load YOLO model
    print("Loading YOLOv11 model...")
    model = YOLO(config.MODEL_PATH)

    # Get video source
    print(f"Connecting to video source: {config.VIDEO_SOURCE}")
    cap, width, height, fps = utils.get_video_source(config.VIDEO_SOURCE)
    print(f"Video resolution: {width}x{height}, FPS: {fps}")

    # Create video writer
    writer = None
    if config.SAVE_OUTPUT:
        writer = utils.create_video_writer(config.OUTPUT_PATH, width, height, config.OUTPUT_FPS)
        print(f"Output video will be saved to: {config.OUTPUT_PATH}")

    # Initialize tracking history and timer
    track_histories = {}
    start_time = time.time()
    frame_count = 0
    fps_value = 0

    print("Starting video processing...")
    while True:
        # Read one frame
        ret, frame = cap.read()
        if not ret:
            print("Video finished or source error")
            break

        # Calculate FPS
        frame_count += 1
        if frame_count % 10 == 0:  # Update FPS every 10 frames
            fps_value = utils.calculate_fps(start_time, frame_count)
            print(f"Processed {frame_count} frames, FPS: {fps_value:.2f}")

        # Perform object tracking
        results = model.track(
            source=frame,
            conf=config.CONF_THRESH,
            iou=config.IOU_THRESH,
            classes=config.CLASSES,
            persist=True,  # Enable cross-frame persistent tracking
            verbose=False
        )

        # Process tracking results
        if results and len(results) > 0:
            result = results[0]  # Get the first result
            annotated_frame = result.plot()  # Get annotated frame

            # If tracking ID exists, update trajectory history
            if hasattr(result, 'boxes') and hasattr(result.boxes, 'id') and result.boxes.id is not None:
                boxes = result.boxes.cpu().numpy()
                for i, box in enumerate(boxes):
                    # Get bounding box and tracking ID
                    x1, y1, x2, y2 = box.xyxy[0].astype(int)
                    track_id = int(box.id[0])

                    # Calculate bounding box center
                    center_x = (x1 + x2) // 2
                    center_y = (y1 + y2) // 2

                    # Update trajectory history
                    track_histories = utils.update_track_history(
                        track_histories, track_id, center_x, center_y
                    )

                # Draw trajectory on the frame
                annotated_frame = utils.draw_tracks(annotated_frame, track_histories)
        else:
            annotated_frame = frame.copy()

        # Show FPS
        annotated_frame = utils.draw_fps(annotated_frame, fps_value)

        # Save output video
        if config.SAVE_OUTPUT and writer is not None:
            writer.write(annotated_frame)

    # Release resources
    cap.release()
    if writer is not None:
        writer.release()

    print(
        f"Processing complete. Total frames: {frame_count}, Average FPS: {frame_count / (time.time() - start_time):.2f}")
    if config.SAVE_OUTPUT:
        print(f"Output video has been saved to: {config.OUTPUT_PATH}")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"Program exception: {e}")
