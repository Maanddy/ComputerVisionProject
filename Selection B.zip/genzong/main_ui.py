# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main_ui.ui'
##
## Created by: Qt User Interface Compiler version 6.7.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QLabel, QPushButton, QSizePolicy,
    QWidget)

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(1399, 853)
        self.name = QLabel(Form)
        self.name.setObjectName(u"name")
        self.name.setGeometry(QRect(500, 20, 411, 111))

        self.video = QPushButton(Form)
        self.video.setObjectName(u"video")
        self.video.setGeometry(QRect(30, 290, 131, 51))


        self.camera = QPushButton(Form)
        self.camera.setObjectName(u"camera")
        self.camera.setGeometry(QRect(30, 460, 131, 51))

        self.exit = QPushButton(Form)
        self.exit.setObjectName(u"exit")
        self.exit.setGeometry(QRect(30, 590, 131, 51))



        self.input = QLabel(Form)
        self.input.setObjectName(u"input")
        self.input.setGeometry(QRect(200, 180, 521, 521))
        self.input.setStyleSheet(u"background-color: rgb(230, 231, 225);")
        self.output = QLabel(Form)
        self.output.setObjectName(u"output")
        self.output.setGeometry(QRect(800, 180, 541, 521))
        self.output.setStyleSheet(u"background-color: rgb(230, 231, 225);")
        self.numname = QLabel(Form)
        self.numname.setObjectName(u"numname")
        self.numname.setGeometry(QRect(610, 780, 121, 51))
        fonts = QFont()
        fonts.setPointSize(16)
        # self.num = QLabel(Form)
        # self.num.setObjectName(u"num")
        # self.num.setGeometry(QRect(750, 790, 101, 41))
        # self.num.setStyleSheet(u"background-color: rgb(230, 231, 225);")
        # self.num.setFont(fonts)
        # self.num.setAlignment(Qt.AlignCenter)

        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.name.setText(QCoreApplication.translate("Form", u"", None))
        self.video.setText(QCoreApplication.translate("Form", u"VIDEO", None))
        self.camera.setText(QCoreApplication.translate("Form", u"CAMERA", None))
        self.exit.setText(QCoreApplication.translate("Form", u"EXIT", None))
        self.input.setText(QCoreApplication.translate("Form", u"TextLabel", None))
        self.output.setText(QCoreApplication.translate("Form", u"TextLabel", None))
        # self.numname.setText(QCoreApplication.translate("Form", u"<html><head/><body><p align=\"center\"><span style=\" font-size:16pt;\">\u68c0\u6d4b\u4eba\u6570</span></p></body></html>", None))
        #self.num.setText(QCoreApplication.translate("Form", u"<html><head/><body><p align=\"center\"><br/></p></body></html>", None))
    # retranslateUi

