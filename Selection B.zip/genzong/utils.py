"""Utility functions module for video processing and visualization."""
import cv2
import numpy as np
import time
from typing import List, Dict, Tuple, Optional, Union
import config


def get_video_source(source: Union[str, int]) -> Tuple[cv2.VideoCapture, int, int, float]:
    """Get the video source and return related video information."""
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        raise ValueError(f"Cannot open video source: {source}")

    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    return cap, width, height, fps


def create_video_writer(output_path: str, width: int, height: int, fps: float) -> cv2.VideoWriter:
    """Create a video writer."""
    fourcc = cv2.VideoWriter_fourcc(*config.VIDEO_CODEC)
    return cv2.VideoWriter(output_path, fourcc, fps, (width, height))


def draw_tracks(frame: np.ndarray, tracks: Dict[int, List[Tuple[int, int]]]) -> np.ndarray:
    """Draw object tracks on the frame."""
    if not config.SHOW_TRACK:
        return frame

    for track_id, points in tracks.items():
        # Generate a unique color based on the track ID
        color = get_color_by_id(track_id)

        # Draw track lines
        if len(points) > 1:
            for i in range(1, len(points)):
                # Line thickness decreases for older points; recent points are thicker
                thickness = max(1, config.LINE_THICKNESS - (len(points) - i) // config.TRACK_FADE_FACTOR)
                cv2.line(frame, points[i - 1], points[i], color, thickness)

    return frame


def get_color_by_id(track_id: int) -> Tuple[int, int, int]:
    """Generate a unique color based on the track ID."""
    # Use a hash of the track ID to generate different colors
    # np.random.seed(track_id * 123456789)
    # b = np.random.randint(100, 255)
    # g = np.random.randint(100, 255)
    # r = np.random.randint(100, 255)

    b = 0
    g = 0
    r = 255
    return (b, g, r)


def draw_fps(frame: np.ndarray, fps: float) -> np.ndarray:
    """Draw FPS information on the frame."""
    if config.SHOW_FPS:
        cv2.putText(
            frame,
            f"FPS: {fps:.1f}",
            (20, 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            config.FONT_SIZE,
            config.TEXT_COLOR,
            config.FONT_THICKNESS
        )
    return frame


def calculate_fps(start_time: float, frame_count: int) -> float:
    """Calculate frames per second (FPS)."""
    current_time = time.time()
    elapsed_time = current_time - start_time
    if elapsed_time > 0:
        return frame_count / elapsed_time
    return 0


def update_track_history(track_histories: Dict[int, List[Tuple[int, int]]],
                         track_id: int,
                         center_x: int,
                         center_y: int) -> Dict[int, List[Tuple[int, int]]]:
    """Update the history of object tracks."""
    if track_id not in track_histories:
        track_histories[track_id] = []

    track_histories[track_id].append((center_x, center_y))

    # Limit the length of the track history to a configured value
    if len(track_histories[track_id]) > config.TRACK_HISTORY_LEN:
        track_histories[track_id] = track_histories[track_id][-config.TRACK_HISTORY_LEN:]

    return track_histories
